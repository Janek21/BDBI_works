from graph import Graph
from random import shuffle
from tsp2approx import TSP2approx # You probably need to write this one first. Comment out the line if it gives you problems.

# We will now construct the example that you can use. The idea is to use the fact that we know from Problem Sheet Graphs & Networks I that the n-cube has a Hamiltonian cycle. 
# So we encode our complete graph of order 2^n such that the vertices are labelled by binary words of length n, and the edge weights are defined by the Hamming distance of the two vertices involved. 
# Hamming distance means "in how many entries do the two vertices differ". 
# This way, the edges of the n-cube will be exactly those of weight 1, and since it has a Hamiltonian cycle, the optimum will be of weight 2^n. 

# We begin with defining a generator for binary words of length n that works recursively.
def generateBinaryWords(n):
    if n==1:
        yield (0,)
        yield (1,)
    else:
        for next in list(generateBinaryWords(n-1)):
            yield next + (0,)
            yield next + (1,)

# This is a function that has as input two vectors of length n (n-tuples) and will output the number of coordinates that they differ in.
def HammingDist(a,b):
    distance = 0
    for coord in range(len(a)):
        if a[coord] != b[coord]:
            distance += 1
    return distance

# We choose n=7 here as an example, but any value works. But remember that your graph will have 2^n vertices, so it is probably better not to choose something too large!
G = Graph()
n=7 # If you want to try other values of n just change this line
vertices = list(generateBinaryWords(n))
shuffle(vertices)
for pair in [[a,b] for a in vertices for b in vertices if a!=b]:
    G.add_edge(pair)

# We now create the weight function. Recall that the output of G.edges() will be a list of sets. The problem is that since objects of type "set" are not hashable, they cannot be keys of a dictionary. So we have to transform them to type "frozenset" before. This type is very similar to "set" but you cannot add or remove any elements from it.
w = dict()
for edge in G.edges():
    a,b = edge # we extract the elements in our edge
    w[frozenset(edge)] = HammingDist(a,b)

# We now test our output. You might need to program this TSP2approx function yourselves, since it is homework ;). In my case, the output of TSP2approx will be a list [v_1,v_2,...,v_(2^n),v1] representing the Hamiltonian cycle.
C = TSP2approx(w)
weight = 0
for i in range(len(C)-1):
    edge = frozenset({C[i],C[i+1]})
    weight += w[edge]
print('The output cycle was '+str(C)+' which has weight '+str(weight)+'. The optimum weight is '+str(2**n)+'.')