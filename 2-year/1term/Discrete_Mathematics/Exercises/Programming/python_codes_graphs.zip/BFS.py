# The basic idea of our BFS implementation will be to create a dictionary that has as keys the vertices of our BFS trees, while each value has its parent as a key.
# The root will have value None.
def BFS(G, r):
    # We choose to keep track of already explored vertices because we do this already by building the BFS tree. 
    # One could also keep track of unexplored vertices, this could be done for example by looking at the set-theoretic difference of the keys of G and T.
    current_level = [r]
    T = {r : None}
    # While there are still vertices to explore the neighborhood of, we continue building the BFS.
    while len(current_level) > 0:
        next_level = []
        for vertex in current_level: 
            for neighbor in G.neighbors(vertex):
                if neighbor not in T.keys():
                    T[neighbor] = vertex
                    next_level.append(neighbor)
        current_level = next_level
    return(T)