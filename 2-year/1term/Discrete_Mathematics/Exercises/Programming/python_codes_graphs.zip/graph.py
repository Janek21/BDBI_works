# Our graph class will be a dictionary containing the vertices as keys, while the values of each key will be that vertex' neighbors.
class Graph(object):
    def __init__(self):
        """ initializes a graph object """
        self.__graph_dict = {}

    def vertices(self):
        """ returns the vertices of a graph """
        return list(self.__graph_dict.keys())

    # Since our data structure is essentially adjacency lists, in order to list all the edges we must iterate through every vertex' list.
    def edges(self):
        """ returns the edges of a graph """
        # Internally edges are handled as a set of frozensets, but will be returned as a list of sets for better readability. This approach means we don't have to worry about edges being added multiple times.
        edges = set()
        
        for vertex in self.__graph_dict:
            for neighbor in self.__graph_dict[vertex]:
                edges.add(frozenset({vertex, neighbor}))
        return [set(edge) for edge in edges]

    def neighbors(self, vertex):
        """ returns the neighbors of a vertex """
        return self.__graph_dict[vertex]

    def add_vertex(self, vertex):
        """ If the vertex "vertex" is not in 
            self.__graph_dict, a key "vertex" with an empty
            list as a value is added to the dictionary. 
            Otherwise nothing has to be done. 
        """
        if vertex not in self.__graph_dict:
            self.__graph_dict[vertex] = set()

    def add_edge(self, edge):
        """ add an edge to the graph """
        (vertex1, vertex2) = tuple(edge)
        
        self.add_vertex(vertex1)
        self.add_vertex(vertex2)

        self.__graph_dict[vertex1].add(vertex2)
        self.__graph_dict[vertex2].add(vertex1)
        
        
# An example application: The random graph on 1000 vertices. 
# Here, each of the possible (1000 choose 2) edges exists independently with probability 0.5, so the expected number of edges is (1000 choose 2)/2 = 1000*999/4. 
# We also return the relative deviation from this mean. Note that by e.g. the law of large numbers, this will go to zero as the number of vertices tends to infinity.
if __name__ == "__main__":
    from random import random
    from math import factorial
    
    graph = Graph()

    for v in range(1000):
        graph.add_vertex(v)
        
    for e in [[a,b] for a in graph.vertices() for b in graph.vertices() if a != b]:
        if random() > 0.5:
            graph.add_edge(e)

    expected_edges = 1000*999/4
    edges = graph.edges()
    rel_error = abs(len(edges)-expected_edges)/expected_edges
        
    print("List of vertices: " + str(graph.vertices())+".")
    print("List of edges: " + str(edges) + ". The relative deviation from the mean is thus " + str(rel_error) + ".")