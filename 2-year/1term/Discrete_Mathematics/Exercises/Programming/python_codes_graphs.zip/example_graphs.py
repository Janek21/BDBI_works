from graph import Graph

# This will contain some graphs that can be used to test your functions, as well as some functions that make them easier to construct. 
# The graphs are given as functions, so you can import the ones from this file.


# The complete graph on n vertices K_n
def compGraph(n):
    G = Graph()
    for a in range(n):
        for b in range(a+1,n):
            G.add_edge([a,b])
    return G


# The complete bipartite graph K_n,m.
def compBipGraph(n,m):
    G = Graph()
    for a in range(n):
        for b in range(n+1,n+m):
            G.add_edge([a,b])
    return G


# An m-ary tree of depth n. This means that every vertex (except for the leaves) has exactly m children, and that the longest path has length 2n.
# We begin with defining a generator for binary words of length n that works recursively.
def aryTree(m,n):
    T = Graph()
    T.add_vertex((0,))
    for _ in range(n):
        for vertex in T.vertices():
            for j in range(m):
                T.add_edge([vertex,vertex+(j,)])
    return T


# The n-cube as defined on Problem Sheet Graphs & Networks I. For this, we implement two functions that will make the construction easier.
# We begin with defining a generator for binary words of length n that works recursively. Recall that these are the vertices of the n-cube.
def generateBinaryWords(n):
    if n==1:
        yield (0,)
        yield (1,)
    else:
        for next in list(generateBinaryWords(n-1)):
            yield next + (0,)
            yield next + (1,)


# This is a function that has as input two vectors of length n (n-tuples) and will output the number of coordinates that they differ in. 
# Recall that the edges of the n-cube are exactly all those between vertices of Hamming distance 1.
def HammingDist(a,b):
    distance = 0
    for coord in range(len(a)):
        if a[coord] != b[coord]:
            distance += 1
    return distance


# We can now write the constructor function.
def cubeGraph(n):
    G = Graph()
    for pair in [[a,b] for a in list(generateBinaryWords(n)) for b in list(generateBinaryWords(n)) if HammingDist(a,b)==1]: # note that we do not require the a!=b check here, since HammingDist(a,a)=0.
        G.add_edge(pair)
    return G


# The path P_n on n vertices
def pathGraph(n):
    P = Graph()
    for index in range(n-1):
        P.add_edge([index,index+1])
    return P


# The cycle C_n on n vertices
def cycleGraph(n):
    C = Graph()
    C.add_edge([0,n-1])
    for index in range(n-1): 
        C.add_edge([index,index+1])
    return C


# Finally, we will define a function that takes as the input two graphs, and outputs the disjoint union of them as a single graph. 
# That is, the output graph will consist of two disconnected components, one corresponding to input graph 1, the other to input graph 2.
def graphDisjUnion(G,H):
    union = Graph()
    # Since the implementation of G and H might share vertex labels, we first make them different by replacing each vertex v in V(G) by the tuple (v,0), similarly for each vertex w in V(H) we replace it by (v,1). Since our internal _add_edge() function already adds vertices, we don't have to explicitly call the add_vertex function.
    for edge in G.edges():
        a,b = tuple(edge)
        new_vertex1 = (a,0)
        new_vertex2 = (b,0)
        union.add_edge([new_vertex1,new_vertex2])
    for edge in H.edges():
        a,b = tuple(edge)
        new_vertex1 = (a,1)
        new_vertex2 = (b,1)
        union.add_edge([new_vertex1,new_vertex2])
    return union