from BFS import BFS


# Our BFS implementation provides us with a dictionary T with keys the vertices of the BFS tree and values the parents of the vertices in this tree. 
# So to get the shortest path from x to y in G, we compute the BFS tree rooted at y, then start at x and go up parent by parent until we reach y.
def shortestPath(G,x,y):
    T = BFS(G,y)
    path = [x]
    parent = T[x]
    while T[parent] != None:
        path.append(parent)
        parent = T[parent]
    print("The shortest path between "+str(x)+" and "+str(y)+" is "+str(path)+".")
    return path


# We track the vertices of G that we have not seen yet and compute BFS trees until there are none left. 
# Meanwhile, for each BFS tree computed we keep a counter to know how many connected components there are. 
# Note that by keeping the BFS tree computed in each iteration of the while loop, we could also provide a list of all connected components of G, instead of just the number.
def numComps(G):
    unexplored_vertices = set(G.vertices())
    counter = 0
    if len(unexplored_vertices)==0: 
    # We need to handle the case where G is the empty graph (sometimes called the null graph) separately. 
    # In this graph, the empty set is an inclusion maximal subset of the vertex set where every pair of vertices can be connected (because there are no pairs), so technically it has 1 connected component.
        return 1
    while len(unexplored_vertices) > 0:
        root = unexplored_vertices.pop()
        T = BFS(G,root)
        unexplored_vertices = unexplored_vertices.difference(T.keys())
        counter += 1
    print("The graph has "+str(counter)+" connected components.")
    return counter


# A tree on n vertices has n-1 edges, which serves as the first check. 
# If this is true, we compute the BFS tree rooted at an arbitrary vertex and check if all vertices of G were explored.
def isTree(G):
    num_vertices =  len(G.vertices())
    num_edges = len(G.edges())
    if num_vertices == 0:
            # Again, we handle the empty graph case separately. If we used the numComps function this could be skipped. 
            # The empty graph is usually considered not a tree, because it does not satisfy the num_vertices = num_edges+1 identity.
        return False
    root = G.vertices()[0]
    # Instead of doing if/else statements, we return the "test boolean" directly: 
    # The first statement checks if we our BFS found every vertex of G, which happens if and only if G is connected.
    # The second asks if G satisfies the edge/vertex identity.
    return len(BFS(G,root))==num_vertices and num_edges+1==num_vertices