from graph import Graph

# For us the weight function w will be a dictionary where the keys are edges (frozensets of two elements) of a graph and the value is the weight. For the output, we choose to return it as a Graph object.
def primMST(w,r):

    # we begin by constructing a graph object from our weight function
    G = Graph()
    for edge in w.keys():
        G.add_edge(edge)

    # We initialize our MST. The list "available_edges" will keep track of all edges together with their weight that we can use to expand our current tree.
    MST = Graph()
    MST.add_vertex(r)
    available_edges = [({r,neighbor}, w[frozenset({r,neighbor})]) for neighbor in G.neighbors(r)]
    while len(available_edges)>0:

        # We first compute the minimum weight edge in our list of available edges. To do this we use an anonymous lambda function to specify that we want the minimum to use the weights. Recall that the elements of available_edges are tuples (e,w(e)), where e is an edge of G.
        min_edge = min(available_edges, key=lambda edge: edge[1])[0]

        # Having the minimum in hand, we first determine the new vertex that was added to our list.
        for vertex in min_edge:
            if vertex not in MST.vertices():
                new_vertex = vertex

        # We now update our available edge list by adding all the new edges that the new vertex provides.
        for neighbor in G.neighbors(new_vertex):
            available_edges.append(({new_vertex,neighbor}, w[frozenset({new_vertex,neighbor})]))

        # Finally we add the new edge to our MST. We do this last so the check for determining the new vertex works.
        MST.add_edge(min_edge)

        # In the last step we throw out any edges that would connect two vertices already in our tree. For this we iterate through the current available edges and compute the size of the intersection of the vertex set of our MST and each available edge. We can do this last since in the very first iteration, we are guaranteed to be fine.
        available_edges = [item for item in available_edges if len(item[0].intersection(MST.vertices()))<2]

    return MST

# This will implement depth-first search. The input parameter G is a graph, while r will be an element of G.vertices(). The output will be a an ordered list of the vertices in the order they were traversed in.
def DFS(G,r):
    # We initialize our tree. The way depth-first search works is that we explore as far down the graph as possible, while keeping track of the branching points on our stack. At any branching point, we add the other possible points to our stack.
    T = [r]
    stack = list(G.neighbors(r))
    
    # The main loop that continues as long as the stack is not finished.
    while len(stack)>0:
        vertex = stack.pop(0) # Take the first element from the stack. The internal function pop(i) will return the element at index i and also remove it from the list.

        # We now check whether the element on top of the stack is already in the tree, in which case we just go to the next one. If it is not, we add it to our tree, and add all its neighbors to the top of the stack.
        if vertex not in T:
            T.append(vertex)
            stack = list(G.neighbors(vertex)) + stack
    
    return T

# Finally, we implement the algorithm defined in the exercise. The input will be a weight function of a complete graph (as a dictionary), and the output will be a list representing a Hamiltonian cycle which will have weight at most twice the optimum if the weight function satisfied the triangle inequality.
def TSP2approx(w):

    # We start by taking a vertex of our graph as the root. Since the weight function only contains edges and their weights, this is a bit convoluted. Let's do it in steps, although all of this can be done in a single line.
    some_edge = list(w.keys())[0] # We take the first edge appearing in our weight function.
    root = list(some_edge)[0] # We transform the set object some_edge to a list and take the first entry. Note that because some_edge will be of type frozenset, the internal pop() function does not exist like it does for type set.

    # We now get the MST using Prim's algorithm
    T = primMST(w,root)

    # We have already set up our DFS algorithm to give out the vertices in the order they are found, so the only thing that remains is to add the root at the end to close the cycle.
    hamCycle = DFS(T,root)
    hamCycle.append(root)

    return hamCycle