from graph import Graph

def prueferTree(code):
    # The labels of the tree start at 1.
    unused_labels = list(range(1,len(code)+3))
    tree = Graph()
    # The code has length n-2 initially and will shrink in size by 1 in each iteration of the while loop. 
    # So at the end there will be 2 unused labels left over, which we will have to add as an edge manually.
    while len(unused_labels) > 2:
        # We want to get the least unused label that does not appear in the (current iteration) of the code. 
        # Using list comprehension, this could possibly be written more concisely in a single line.
        for i in range(len(unused_labels)):
            if unused_labels[i] not in code:
                current_label = unused_labels.pop(i)
                break
        # One thing to note here is that the add_edge function of our Graph class already adds the participating vertices, so using add_vertex beforehand would be redundant.
        vert = code.pop(0)
        tree.add_edge([vert,current_label])
    tree.add_edge([unused_labels[0],unused_labels[1]])
    return tree

code = [3, 1, 1, 2, 2, 2, 3, 3]
T=prueferTree(code)
print(T)