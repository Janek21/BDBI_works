# We will need to use the factorial of an integer for this program.
# You could easily define it yourself with something like:
#
# factorial = lambda n: n * (factorial(n-1) if n > 1 else 1)
#
# We are instead using the math library built into python.
# You can either say 'import math' and then use 'math.factorial
# or alternative use 'from math import factorial' and just use 'factorial'
from math import factorial

# The word we are considering is given as a simple string
word = 'AACTGGATACGA' #'ANTIDISESTABLISHMENTARIANISM' #'MISSISSIPPI' #alternatively you can also try 'GUADALQUIVIR' or 'ANNA'

# We start with the assumption that all characters in 'word'
# are distinct and determine the number of ways to rearrange them
rearrangementnumber = factorial(len(word))

# Next, we correct for the multiple occurrences of the characters.
# For this, we need a list of all characters used in the word.
# The easiest way to obtain those, is to turn the string 'word'
# into a set, which treats the string as a list of individiual
# characters and then removes duplicates
characters = set(word)

# Next, we loop through each character in 'characters' and correct
# the variable 'rearrangementnumber' for its multiple occurrences
for c in characters:
    # if you want to check the number of occurrences, use e.g. 
    # print c + " appears " + str(word.count(c)) + "x in "+word
    
    # For the character 'c' we divide 'rearrangementnumber' by the
    # factorial of the occurrences of 'c' in 'word'
    rearrangementnumber = rearrangementnumber/factorial(word.count(c))
    
# Finally, we just have to output 'rearrangementnumber'
print("There are "+str(rearrangementnumber)+" ways to rearrange the word "+word)