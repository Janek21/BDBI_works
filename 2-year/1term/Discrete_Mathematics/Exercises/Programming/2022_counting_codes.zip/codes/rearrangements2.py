# This is an example of how you ideally SHOULD NOT do such a script.
# While it delivers the correct answer, the usage of 'itertools.permutations'
# means every single rearrangement (ignoring multiplicity of characters)
# needs to be determined and stored in memory, slwoing this script down
# even for medium sized words

import itertools

word = 'AACTGGATACGA' #'ANTIDISESTABLISHMENTARIANISM' #'MISSISSIPPI' #'MISSISSIPPI' #'GUADALQUIVIR'

# 'itertools.permutations(word)' determines all rearrangements of the words.
# This ignores the multiplicity of the characters, so we need to turn this
# into a set to remove duplicates.
rearrangements = set(itertools.permutations(word))

print("There are "+str(len(rearrangements))+" ways to rearrange the word "+word)