### FUNCTION DEFINITIONS ARE HERE ###

# The first function determines the Fibonacci number F_n
# iteratively using a for-loop. Alternatively, one could
# also use the closed expression derived in the lecture here.
def fib(n):
    """Return the Fibonacci number F_n"""
    
    # These are the starting values F_0 and F_1
    a,b = 0,1

    # For these kinds of loops you should always make sure
    # that you are using the right kind of indexing. Checking
    # some base cases n = 0,1,2,3 helps for this
    for i in range(n):
        a,b = b,a+b
    
    # Returning 'a' as F_n means that we always calulate
    # one number to far (since 'b' is F_(n+1)) but this way
    # the code is cleaner and does not require an if statement
    # to catch the case n == 0
    return a


# The second function creates a list of all Fibonacci numbers
# smaller than some given 'm' again through an iterative loop.
def fib_upto(m):
    """Return all Fibonacci numbers up to n"""
    
    # We handle the F_0 case separately
    if m == 0:
        return [0]
    else:
    
        # This is a list containing the starting values F_0 and F_1
        fnumbers = [0,1]
    
        # We do a loop that appends a number as long as it's not too big
        while fnumbers[-1] <= m:
            fnumbers.append(fnumbers[-1]+fnumbers[-2])
            
        # return the list of all calculated values except for the last one
        # as this will be too large
        return fnumbers[:-1]
   
        
### THE MAIN CODE STARTS HERE ###
      

# Just checking if 'fib' works by checking n = 0,...,19.
# The 'ljust' just gives us some slightly nicer formatting
# when printing the results in the console
for n in range(20):
    print(("F_" + str(n)).ljust(4) + "  =  " + str(fib(n)).ljust(5))
    
# Checking if 'fib_upto' works by printing all Fibonacci
# numbers smaller than or equal to 4200. These should in
# fact be the same numbers as printed above
print(fib_upto(4200))