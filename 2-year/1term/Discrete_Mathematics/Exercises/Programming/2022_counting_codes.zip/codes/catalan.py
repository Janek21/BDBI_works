# We will need the factorial again as well as the timeit.timeit
# function so we import the two appropriate libraries
import math, timeit


### FUNCTION DEFINITIONS ARE HERE ###

# A handy shortcut to define a function that puts out the binomial.
# You can also use the usual 'def binomial(a,b):' if you prefer 
binomial = lambda a,b: int(math.factorial(a)/(math.factorial(b)*math.factorial(a-b)) if a >= b else 0)

# This function just uses the direct formula to return C_n
def catalan_direct(n):
    return binomial(2*n,n) - binomial(2*n,n+1)

# This function uses a for-loop to iteratively determine the Catalan
# numbers from C_0, C_1, ..., C_n and then returns C_n. This works
# very much like the function 'fib' from the previous exercise.
def catalan_loop(n):
    cnumbers = [1]
    
    for i in range(1,n+1):
        # This is jut a fancy way to avoid another for-loop. Check
        # 'list comprehensions' as well as the 'zip' function in
        # the python documentation in order to unpack this statement
        cnumbers.append(sum([a*b for a,b in zip(cnumbers,reversed(cnumbers))]))
        # Alternatively you could of course also just use something like this:
        # 
        # c = 0
        # for j in range(len(cnumbers)):
        #    c += cnumbers[j]*cnumbers[len(cnumbers)-j-1]
        #
        # cnumbers.append(c)
        
    # pop() removes and then returns the last value of a list
    # in a computationally very effective manner. Alternatively
    # you could also just use 'return cnumbers[-1]'.
    return cnumbers.pop()
    
    
# This recursive function is again an example for how to NOT implement
# a problem like this. The recursive nature of this means that many of 
# the values C_1,...,C_(n-1) are unnecessarily created many many times 
# and then forgotten again, giving you an exponential runtime compared
# to the linear runtime of the previous two functions.
def catalan_recursive(n):
    if n == 0:
        return 1
    else:
        # This creates a list ofall necessary previous Catalan numbers
        prev_numbers = [catalan_recursive(i) for i in range(n)]
        # Again, this list comprehension expression just replaces this:
        #
        # prev_numbers = []
        # for i in range(n):
        #    prev_numbers.append(catalan_recursive(i))
        
        # This shortened expression is the same that occurrs in 'catalan_loop'
        # nd can be unpacked into a for loop as shown there
        return sum([a*b for a,b in zip(prev_numbers,reversed(prev_numbers))])
        
    
### THE MAIN CODE STARTS HERE ###
      
# This if-statement is not necessary for this code to run
# but it means that this bit of code is executed only if this
# file is run directly and ignored if you import it somewhere
# else (for example to use the functions you just created).
if __name__ == "__main__":
    # The following times how long it takes to run the three functions
    # for n = 20 and prints the result in seconds
    print(timeit.timeit('catalan_direct(20)','from __main__ import catalan_direct', number=1))
    print(timeit.timeit('catalan_loop(20)','from __main__ import catalan_loop', number=1))
    print(timeit.timeit('catalan_recursive(20)','from __main__ import catalan_recursive', number=1))
    
    # If you would like your program to be somewhat nicer to use and
    # more interactive, allowing you to try out different values for
    # 'n' during runtime, you could use something likes this instead
    # of the previous three lines:
    # 
    # while True:
    #     userinput = input("Please enter a number: ")
    #     
    #     if userinput in ["exit","quit"]:
    #         break
    #     else:
    #         n, repetitions = int(userinput), 1
    #
    #     print("The direct implementation took {}s".format(timeit.timeit('catalan_direct({})'.format(n),'from __main__ import catalan_direct', number=repetitions)))
    #     print("The loop implementation took {}s".format(timeit.timeit('catalan_loop({})'.format(n),'from __main__ import catalan_loop', number=repetitions)))
    #     print("The recursive implementation took {}s".format(timeit.timeit('catalan_recursive({})'.format(n),'from __main__ import catalan_recursive', number=repetitions)))